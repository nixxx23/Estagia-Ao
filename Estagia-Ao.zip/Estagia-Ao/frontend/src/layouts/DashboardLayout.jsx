import React from 'react';
import { LayoutDashboard, Users, Building, Settings } from 'lucide-react';
import { Link, Outlet } from 'react-router-dom';
export default function DashboardLayout() {
  return (
    <div className="min-h-screen flex bg-[#E6F0FF]">
      <aside className="w-64 bg-[#007BFF] text-white flex flex-col">
        <div className="p-6 text-center text-xl font-bold border-b border-blue-300">
          Estagia-Ao
        </div>
        <nav className="flex-1 p-4 space-y-3">
          <Link className="flex items-center gap-3 hover:bg-blue-600 p-2 rounded" to="/">
            <LayoutDashboard size={20}/> Dashboard
          </Link>
          <Link className="flex items-center gap-3 hover:bg-blue-600 p-2 rounded" to="/alunos">
            <Users size={20}/> Alunos
          </Link>
          <Link className="flex items-center gap-3 hover:bg-blue-600 p-2 rounded" to="/unidades">
            <Building size={20}/> Unidades
          </Link>
        </nav>
        <div className="p-4 border-t border-blue-300">
          <Link className="flex items-center gap-3 hover:bg-blue-600 p-2 rounded" to="/config">
            <Settings size={20}/> Configurações
          </Link>
        </div>
      </aside>
      <main className="flex-1 p-6 bg-white rounded-tl-3xl shadow-inner overflow-y-auto">
        <Outlet />
      </main>
    </div>
  );
}
