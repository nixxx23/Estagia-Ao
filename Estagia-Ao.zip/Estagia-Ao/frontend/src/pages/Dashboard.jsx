import React from 'react';
import { Users, Building2, FileText } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ComposableMap, Geographies, Geography } from 'react-simple-maps';
const geoUrl = "https://raw.githubusercontent.com/deldersveld/topojson/master/countries/angola/angola-provinces.json";
export default function Dashboard() {
  const stats = [
    { icon: <Users />, label: 'Total de Alunos', value: 1200 },
    { icon: <Building2 />, label: 'Unidades de Saúde', value: 35 },
    { icon: <FileText />, label: 'Estágios Ativos', value: 280 }
  ];
  const dataBarras = [
    { curso: 'Enfermagem', alunos: 400 },
    { curso: 'Medicina', alunos: 300 },
    { curso: 'Fisioterapia', alunos: 150 },
    { curso: 'Laboratório', alunos: 200 },
    { curso: 'Farmácia', alunos: 150 }
  ];
  const dataLinha = [
    { mes: 'Jan', estagios: 100 },
    { mes: 'Fev', estagios: 140 },
    { mes: 'Mar', estagios: 180 },
    { mes: 'Abr', estagios: 200 },
    { mes: 'Mai', estagios: 260 },
    { mes: 'Jun', estagios: 280 }
  ];
  const dataMapa = [
    { prov: 'Luanda', alunos: 500 },
    { prov: 'Huíla', alunos: 150 },
    { prov: 'Benguela', alunos: 200 },
    { prov: 'Huambo', alunos: 100 },
    { prov: 'Cabinda', alunos: 80 },
    { prov: 'Uíge', alunos: 70 },
    { prov: 'Namibe', alunos: 50 }
  ];
  const getCor = (prov) => {
    const reg = dataMapa.find(d => prov.includes(d.prov));
    if (!reg) return '#E6F0FF';
    const intensidade = Math.min(reg.alunos / 500, 1);
    return `rgba(0, 123, 255, ${intensidade})`;
  };
  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold text-[#007BFF]">Painel de Controlo</h1>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        {stats.map((s, i) => (
          <div key={i} className="bg-[#E6F0FF] p-6 rounded-xl shadow-sm flex items-center gap-4">
            <div className="text-[#007BFF]">{s.icon}</div>
            <div>
              <p className="text-gray-600 text-sm">{s.label}</p>
              <h3 className="text-xl font-semibold text-gray-800">{s.value}</h3>
            </div>
          </div>
        ))}
      </div>
      <div className="bg-white p-6 rounded-xl shadow border border-gray-100">
        <h2 className="text-lg font-semibold text-gray-700 mb-4">Distribuição de Alunos por Curso</h2>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={dataBarras} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="curso" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="alunos" fill="#007BFF" radius={[5, 5, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="bg-white p-6 rounded-xl shadow border border-gray-100">
        <h2 className="text-lg font-semibold text-gray-700 mb-4">Evolução de Estágios Ativos (Mensal)</h2>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={dataLinha}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="mes" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="estagios" stroke="#007BFF" strokeWidth={3} dot={{ r: 5 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="bg-white p-6 rounded-xl shadow border border-gray-100">
        <h2 className="text-lg font-semibold text-gray-700 mb-4">Distribuição de Alunos por Província</h2>
        <div className="flex justify-center">
          <ComposableMap projection="geoMercator" projectionConfig={{ scale: 800, center: [18, -12] }} width={600} height={600}>
            <Geographies geography={geoUrl}>
              {({ geographies }) => geographies.map((geo) => (
                <Geography key={geo.rsmKey} geography={geo} fill={getCor(geo.properties.NAME_1)} stroke="#fff" strokeWidth={0.5} />
              ))}
            </Geographies>
          </ComposableMap>
        </div>
      </div>
    </div>
  );
}
