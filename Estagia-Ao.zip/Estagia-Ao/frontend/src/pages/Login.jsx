import React, { useState } from 'react';
export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const handleSubmit = e => { e.preventDefault(); alert('Login simulado!'); };
  return (
    <div className="h-screen flex items-center justify-center bg-[#E6F0FF]">
      <div className="bg-white shadow-lg rounded-2xl p-8 w-96">
        <h1 className="text-2xl font-bold text-center text-[#007BFF] mb-4">Estagia-Ao</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-gray-700">Email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full mt-1 border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-[#007BFF]" />
          </div>
          <div>
            <label className="block text-sm text-gray-700">Palavra-passe</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full mt-1 border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-[#007BFF]" />
          </div>
          <button type="submit" className="w-full bg-[#007BFF] text-white font-semibold rounded-md py-2 hover:bg-[#0056CC] transition">Entrar</button>
        </form>
      </div>
    </div>
  );
}
