import React, { useEffect, useState } from 'react';
import api from '../services/api';
export default function Alocacao() {
  const [alunos, setAlunos] = useState([]);
  const [unidades, setUnidades] = useState([]);
  const [result, setResult] = useState(null);
  useEffect(() => {
    api.get('/alunos').then(r => setAlunos(r.data)).catch(()=>{});
    api.get('/unidades').then(r => setUnidades(r.data)).catch(()=>{});
  }, []);
  const runAllocate = async () => {
    const payload = { alunos: alunos.map(a=>a.id), unidades: unidades.map(u=>({id:u.id,capacidade:u.capacidade||5})) };
    const res = await api.post('/allocate', payload).catch(()=>({data:null}));
    setResult(res.data);
  };
  return (
    <div className="p-4"><h2 className="text-xl font-bold">Alocação automática (teste)</h2>
      <button onClick={runAllocate} className="mt-2 px-4 py-2 rounded border bg-[#007BFF] text-white">Executar alocação</button>
      <pre className="mt-4 bg-gray-100 p-2 rounded">{JSON.stringify(result, null, 2)}</pre>
    </div>
  );
}
