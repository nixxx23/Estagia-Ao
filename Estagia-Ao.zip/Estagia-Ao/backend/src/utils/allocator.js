function simpleAllocate(alunos, unidades) {
  const allocation = {};
  let idx = 0;
  unidades.forEach(u => {
    allocation[u.id] = [];
    while (allocation[u.id].length < u.capacidade && idx < alunos.length) {
      allocation[u.id].push(alunos[idx]);
      idx++;
    }
  });
  const pendentes = alunos.slice(idx);
  return { allocation, pendentes };
}
module.exports = { simpleAllocate };
