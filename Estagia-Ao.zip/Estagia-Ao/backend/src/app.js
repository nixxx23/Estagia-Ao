const express = require('express');
const cors = require('cors');
const sequelize = require('./config/db');
require('dotenv').config();
const app = express();
app.use(cors());
app.use(express.json());
app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/alunos', require('./routes/alunos.routes'));
app.use('/api/unidades', require('./routes/unidades.routes'));
app.use('/api/allocate', require('./routes/allocate.routes'));
app.get('/health', async (req, res) => {
  try {
    await sequelize.authenticate();
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});
module.exports = app;
