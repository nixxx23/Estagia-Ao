const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');
const Unidade = sequelize.define('Unidade', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  nome: { type: DataTypes.STRING, allowNull: false },
  localizacao: { type: DataTypes.STRING, allowNull: true },
  capacidade: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 5 }
});
module.exports = Unidade;
