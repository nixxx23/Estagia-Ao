const express = require('express');
const router = express.Router();
// Endpoints de autenticação (placeholder)
router.post('/login', (req, res) => {
  res.json({ ok: true, token: 'token-simulacao' });
});
module.exports = router;
