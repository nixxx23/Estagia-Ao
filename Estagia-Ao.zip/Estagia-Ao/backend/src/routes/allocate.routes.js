const express = require('express');
const router = express.Router();
const allocator = require('../utils/allocator');
router.post('/', async (req, res) => {
  try {
    const { alunos, unidades } = req.body;
    const result = allocator.simpleAllocate(alunos, unidades);
    res.json({ ok: true, allocation: result });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});
module.exports = router;
