const express = require('express');
const router = express.Router();
const Unidade = require('../models/unidade.model');
router.get('/', async (req, res) => {
  const list = await Unidade.findAll();
  res.json(list);
});
router.post('/', async (req, res) => {
  const { nome, localizacao, capacidade } = req.body;
  const u = await Unidade.create({ nome, localizacao, capacidade });
  res.json(u);
});
module.exports = router;
