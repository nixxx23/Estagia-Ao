const express = require('express');
const router = express.Router();
const Aluno = require('../models/aluno.model');
router.get('/', async (req, res) => {
  const list = await Aluno.findAll();
  res.json(list);
});
router.post('/', async (req, res) => {
  const { nome, email, contacto, turma_id } = req.body;
  const a = await Aluno.create({ nome, email, contacto, turma_id });
  res.json(a);
});
module.exports = router;
