# Estagia-Ao

Projeto completo (scaffold) para gestão de estágios em unidades de saúde — frontend (React + Tailwind + Recharts) e backend (Node.js + Express + Sequelize + Postgres).

## Como usar

### Com Docker
1. Copiar .env.example para backend/.env e ajustar se necessário.
2. Executar: `docker-compose up --build`

### Local (sem Docker)
- Backend:
  ```
  cd backend
  cp .env.example .env
  npm install
  npm run dev
  ```
- Frontend:
  ```
  cd frontend
  npm install
  npm run dev
  ```

## Observações
- Alguns endpoints e modelos são placeholders para acelerar o início do desenvolvimento.
- O nome do projeto foi alterado para **Estagia-Ao** conforme solicitado.
